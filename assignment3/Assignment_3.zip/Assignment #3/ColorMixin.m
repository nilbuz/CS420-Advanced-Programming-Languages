classdef ColorMixin
    
    properties
        color
    end
    
    methods
        function obj = ColorMixin(color)
            obj.color = color;
        end
        
        function obj = SetColor(obj, newColor)
            obj.color = newColor;
        end

        function color = GetColor(obj)
            color = obj.color;
        end
    end
end

        
        % This getter method also works:
        %function color = get.color(obj)
            %color = obj.color;
        %end
        
        % Inputs that work:
        % >> blueCircle.color
        % >> GetColor(blueCircle)
        % >> blueCircle.GetColor